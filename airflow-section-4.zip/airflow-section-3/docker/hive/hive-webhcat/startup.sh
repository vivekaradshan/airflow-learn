#!/bin/bash

cd ${HIVE_HOME}/hcatalog/sbin
./webhcat_server.sh foreground