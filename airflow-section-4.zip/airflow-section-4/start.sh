#!/bin/bash

# Startup all the containers at once
docker-compose up -d --build
