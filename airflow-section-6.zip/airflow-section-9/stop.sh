#!/bin/bash
docker-compose -f docker-compose-CeleryExecutor.yml down